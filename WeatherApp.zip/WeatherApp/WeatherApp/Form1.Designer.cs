﻿namespace WeatherApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btncity = new System.Windows.Forms.Label();
            this.TBcity = new System.Windows.Forms.TextBox();
            this.btnSearchbox = new System.Windows.Forms.Button();
            this.btncondition = new System.Windows.Forms.Label();
            this.btndetail = new System.Windows.Forms.Label();
            this.picicon = new System.Windows.Forms.PictureBox();
            this.btnsunset = new System.Windows.Forms.Label();
            this.btnsunrise = new System.Windows.Forms.Label();
            this.btnwind = new System.Windows.Forms.Label();
            this.btnpressure = new System.Windows.Forms.Label();
            this.btNA1 = new System.Windows.Forms.Label();
            this.btNA2 = new System.Windows.Forms.Label();
            this.btNA4 = new System.Windows.Forms.Label();
            this.btNA3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picicon)).BeginInit();
            this.SuspendLayout();
            // 
            // btncity
            // 
            this.btncity.AutoSize = true;
            this.btncity.BackColor = System.Drawing.Color.Transparent;
            this.btncity.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncity.ForeColor = System.Drawing.Color.White;
            this.btncity.Location = new System.Drawing.Point(92, 124);
            this.btncity.Name = "btncity";
            this.btncity.Size = new System.Drawing.Size(52, 26);
            this.btncity.TabIndex = 0;
            this.btncity.Text = "CITY:";
            // 
            // TBcity
            // 
            this.TBcity.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBcity.ForeColor = System.Drawing.Color.Black;
            this.TBcity.Location = new System.Drawing.Point(147, 124);
            this.TBcity.Name = "TBcity";
            this.TBcity.Size = new System.Drawing.Size(228, 33);
            this.TBcity.TabIndex = 1;
            this.TBcity.TextChanged += new System.EventHandler(this.TBcity_TextChanged);
            // 
            // btnSearchbox
            // 
            this.btnSearchbox.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchbox.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchbox.ForeColor = System.Drawing.Color.White;
            this.btnSearchbox.Location = new System.Drawing.Point(403, 124);
            this.btnSearchbox.Name = "btnSearchbox";
            this.btnSearchbox.Size = new System.Drawing.Size(82, 33);
            this.btnSearchbox.TabIndex = 2;
            this.btnSearchbox.Text = "Search";
            this.btnSearchbox.UseVisualStyleBackColor = false;
            this.btnSearchbox.Click += new System.EventHandler(this.btnSearchbox_Click);
            // 
            // btncondition
            // 
            this.btncondition.AutoSize = true;
            this.btncondition.BackColor = System.Drawing.Color.Transparent;
            this.btncondition.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncondition.ForeColor = System.Drawing.Color.White;
            this.btncondition.Location = new System.Drawing.Point(92, 320);
            this.btncondition.Name = "btncondition";
            this.btncondition.Size = new System.Drawing.Size(95, 26);
            this.btncondition.TabIndex = 3;
            this.btncondition.Text = "Condition";
            // 
            // btndetail
            // 
            this.btndetail.AutoSize = true;
            this.btndetail.BackColor = System.Drawing.Color.Transparent;
            this.btndetail.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndetail.ForeColor = System.Drawing.Color.White;
            this.btndetail.Location = new System.Drawing.Point(92, 370);
            this.btndetail.Name = "btndetail";
            this.btndetail.Size = new System.Drawing.Size(70, 26);
            this.btndetail.TabIndex = 4;
            this.btndetail.Text = "Details";
            // 
            // picicon
            // 
            this.picicon.BackColor = System.Drawing.Color.Transparent;
            this.picicon.Location = new System.Drawing.Point(97, 213);
            this.picicon.Name = "picicon";
            this.picicon.Size = new System.Drawing.Size(133, 82);
            this.picicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picicon.TabIndex = 15;
            this.picicon.TabStop = false;
            // 
            // btnsunset
            // 
            this.btnsunset.AutoSize = true;
            this.btnsunset.BackColor = System.Drawing.Color.Transparent;
            this.btnsunset.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsunset.ForeColor = System.Drawing.Color.White;
            this.btnsunset.Location = new System.Drawing.Point(182, 432);
            this.btnsunset.Name = "btnsunset";
            this.btnsunset.Size = new System.Drawing.Size(45, 26);
            this.btnsunset.TabIndex = 16;
            this.btnsunset.Text = "N/A";
            this.btnsunset.Click += new System.EventHandler(this.btnsunset_Click);
            // 
            // btnsunrise
            // 
            this.btnsunrise.AutoSize = true;
            this.btnsunrise.BackColor = System.Drawing.Color.Transparent;
            this.btnsunrise.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsunrise.ForeColor = System.Drawing.Color.White;
            this.btnsunrise.Location = new System.Drawing.Point(182, 493);
            this.btnsunrise.Name = "btnsunrise";
            this.btnsunrise.Size = new System.Drawing.Size(45, 26);
            this.btnsunrise.TabIndex = 17;
            this.btnsunrise.Text = "N/A";
            // 
            // btnwind
            // 
            this.btnwind.AutoSize = true;
            this.btnwind.BackColor = System.Drawing.Color.Transparent;
            this.btnwind.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnwind.ForeColor = System.Drawing.Color.White;
            this.btnwind.Location = new System.Drawing.Point(675, 320);
            this.btnwind.Name = "btnwind";
            this.btnwind.Size = new System.Drawing.Size(45, 26);
            this.btnwind.TabIndex = 18;
            this.btnwind.Text = "N/A";
            // 
            // btnpressure
            // 
            this.btnpressure.AutoSize = true;
            this.btnpressure.BackColor = System.Drawing.Color.Transparent;
            this.btnpressure.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpressure.ForeColor = System.Drawing.Color.White;
            this.btnpressure.Location = new System.Drawing.Point(675, 370);
            this.btnpressure.Name = "btnpressure";
            this.btnpressure.Size = new System.Drawing.Size(45, 26);
            this.btnpressure.TabIndex = 19;
            this.btnpressure.Text = "N/A";
            // 
            // btNA1
            // 
            this.btNA1.AutoSize = true;
            this.btNA1.BackColor = System.Drawing.Color.Transparent;
            this.btNA1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNA1.ForeColor = System.Drawing.Color.White;
            this.btNA1.Location = new System.Drawing.Point(96, 493);
            this.btNA1.Name = "btNA1";
            this.btNA1.Size = new System.Drawing.Size(80, 26);
            this.btNA1.TabIndex = 20;
            this.btNA1.Text = "Sunrise:";
            this.btNA1.Click += new System.EventHandler(this.btNA1_Click);
            // 
            // btNA2
            // 
            this.btNA2.AutoSize = true;
            this.btNA2.BackColor = System.Drawing.Color.Transparent;
            this.btNA2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNA2.ForeColor = System.Drawing.Color.White;
            this.btNA2.Location = new System.Drawing.Point(96, 432);
            this.btNA2.Name = "btNA2";
            this.btNA2.Size = new System.Drawing.Size(75, 26);
            this.btNA2.TabIndex = 21;
            this.btNA2.Text = "Sunset:";
            // 
            // btNA4
            // 
            this.btNA4.AutoSize = true;
            this.btNA4.BackColor = System.Drawing.Color.Transparent;
            this.btNA4.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNA4.ForeColor = System.Drawing.Color.White;
            this.btNA4.Location = new System.Drawing.Point(545, 370);
            this.btNA4.Name = "btNA4";
            this.btNA4.Size = new System.Drawing.Size(90, 26);
            this.btNA4.TabIndex = 22;
            this.btNA4.Text = "Pressure:";
            // 
            // btNA3
            // 
            this.btNA3.AutoSize = true;
            this.btNA3.BackColor = System.Drawing.Color.Transparent;
            this.btNA3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNA3.ForeColor = System.Drawing.Color.White;
            this.btNA3.Location = new System.Drawing.Point(536, 320);
            this.btNA3.Name = "btNA3";
            this.btNA3.Size = new System.Drawing.Size(121, 26);
            this.btNA3.TabIndex = 23;
            this.btNA3.Text = "Wind Speed:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(934, 569);
            this.Controls.Add(this.btNA3);
            this.Controls.Add(this.btNA4);
            this.Controls.Add(this.btNA2);
            this.Controls.Add(this.btNA1);
            this.Controls.Add(this.btnpressure);
            this.Controls.Add(this.btnwind);
            this.Controls.Add(this.btnsunrise);
            this.Controls.Add(this.btnsunset);
            this.Controls.Add(this.picicon);
            this.Controls.Add(this.btndetail);
            this.Controls.Add(this.btncondition);
            this.Controls.Add(this.btnSearchbox);
            this.Controls.Add(this.TBcity);
            this.Controls.Add(this.btncity);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picicon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label btncity;
        private System.Windows.Forms.TextBox TBcity;
        private System.Windows.Forms.Button btnSearchbox;
        private System.Windows.Forms.Label btncondition;
        private System.Windows.Forms.Label btndetail;
        private System.Windows.Forms.PictureBox picicon;
        private System.Windows.Forms.Label btnsunset;
        private System.Windows.Forms.Label btnsunrise;
        private System.Windows.Forms.Label btnwind;
        private System.Windows.Forms.Label btnpressure;
        private System.Windows.Forms.Label btNA1;
        private System.Windows.Forms.Label btNA2;
        private System.Windows.Forms.Label btNA4;
        private System.Windows.Forms.Label btNA3;
    }
}

