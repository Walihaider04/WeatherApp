﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net;
using static System.Net.WebRequestMethods;

namespace WeatherApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string APIKey = "ef7345af2d30e5bef26ebcaae52d5a3f";

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSearchbox_Click(object sender, EventArgs e)
        {
            getWeather();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        void getWeather()
        {
            using (WebClient web = new WebClient())
            {
                string url = string.Format("https://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}", TBcity.Text, APIKey);
                var json = web.DownloadString(url);
                weatherInfo.root info = JsonConvert.DeserializeObject<weatherInfo.root>(json);
                picicon.ImageLocation = "https://openweathermap.org/img/w/" + info.weather[0].icon + ".png";
                btncondition.Text = info.weather[0].main;
                btndetail.Text = info.weather[0].main;
                btnsunrise.Text = convertDateTime(info.sys.sunrise).ToShortTimeString();
                btnsunset.Text = convertDateTime(info.sys.sunset).ToShortTimeString();

                btnwind.Text = info.wind.speed.ToString(); 
                btnpressure.Text = info.main.pressure.ToString();


            }

            DateTime convertDateTime(long millisec)
                {
                DateTime day = new DateTime(1970 ,1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc).ToLocalTime();
                day = day.AddSeconds(millisec).ToLocalTime();
                return day;

            }

        }
        
        


        private void btNA1_Click(object sender, EventArgs e)
        {

        }

        private void btnsunset_Click(object sender, EventArgs e)
        {

        }

        private void TBcity_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
